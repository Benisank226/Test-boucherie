<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../lib/token.php';

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['token']) || empty($data['password'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Token et nouveau mot de passe requis']);
    exit;
}

// Valider le token
$tokens = file_exists('tokens.json') ? json_decode(file_get_contents('tokens.json'), true) : [];

if (!array_key_exists($data['token'], $tokens)) {
    http_response_code(404);
    echo json_encode(['message' => 'Token invalide']);
    exit;
}

if ($tokens[$data['token']]['expires'] < time()) {
    http_response_code(410);
    echo json_encode(['message' => 'Token expiré']);
    exit;
}

// Mettre à jour le mot de passe (simulation)
$users = [
    'client@example.com' => [
        'id' => 1,
        'password' => password_hash($data['password'], PASSWORD_DEFAULT)
    ]
];

// Supprimer le token utilisé
unset($tokens[$data['token']]);
file_put_contents('tokens.json', json_encode($tokens));

http_response_code(200);
echo json_encode(['message' => 'Mot de passe réinitialisé avec succès']);
