document.addEventListener('DOMContentLoaded', function() {
    const resetPasswordForm = document.getElementById('resetPasswordForm');
    const notification = document.getElementById('notification');
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');

    // Vérifier la présence du token
    if (!token) {
        window.location.href = 'password-reset.html';
        return;
    }

    // Injecter le token dans le formulaire
    document.getElementById('token').value = token;

    if (resetPasswordForm) {
        resetPasswordForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const form = e.target;
            const submitButton = form.querySelector('button[type="submit"]');
            const password = form.password.value;
            const confirmPassword = form.confirmPassword.value;
            
            // Validation
            if (!validatePassword(password)) {
                showError('password-error', 'Le mot de passe ne respecte pas les exigences');
                return;
            }
            
            if (password !== confirmPassword) {
                showError('confirmPassword-error', 'Les mots de passe ne correspondent pas');
                return;
            }
            
            // Désactiver le bouton pendant la requête
            form.classList.add('loading');
            submitButton.disabled = true;
            
            try {
                const response = await fetch('backend/api/auth/reset-password.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        token: token,
                        password: password
                    })
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    showNotification(
                        'Votre mot de passe a été réinitialisé avec succès. Vous pouvez maintenant vous connecter.',
                        'success'
                    );
                    
                    // Redirection après délai
                    setTimeout(() => {
                        window.location.href = 'login.html';
                    }, 3000);
                } else {
                    throw new Error(data.message || 'Erreur lors de la réinitialisation');
                }
            } catch (error) {
                console.error('Erreur:', error);
                showNotification(error.message, 'error');
            } finally {
                form.classList.remove('loading');
                submitButton.disabled = false;
            }
        });
    }

    function validatePassword(password) {
        // Au moins 8 caractères, une majuscule, un chiffre et un caractère spécial
        const re = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return re.test(password);
    }

    function showError(elementId, message) {
        const errorElement = document.getElementById(elementId);
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.classList.add('show');
        }
    }

    function showNotification(message, type = 'success') {
        if (!notification) return;
        
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        notification.className = `auth-notification show ${type}`;
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 5000);
    }
});
