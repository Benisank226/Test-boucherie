<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../lib/token.php';

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['token'])) {
    http_response_code(400);
    echo json_encode(['valid' => false, 'message' => 'Token manquant']);
    exit;
}

$token = $data['token'];

// Vérifier le token en base (simulé)
$tokens = file_exists('tokens.json') ? json_decode(file_get_contents('tokens.json'), true) : [];

if (!array_key_exists($token, $tokens)) {
    http_response_code(404);
    echo json_encode(['valid' => false, 'message' => 'Token invalide']);
    exit;
}

if ($tokens[$token]['expires'] < time()) {
    http_response_code(410);
    echo json_encode(['valid' => false, 'message' => 'Token expiré']);
    exit;
}

http_response_code(200);
echo json_encode([
    'valid' => true,
    'user_id' => $tokens[$token]['user_id'],
    'email' => $tokens[$token]['email']
]);
