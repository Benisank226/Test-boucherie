<?php
class Token {
    private static $secretKey = 'votre_cle_secrete_tres_securisee';
    private static $algorithm = 'HS256';
    
    public static function generateResetToken($userId) {
        $header = json_encode(['typ' => 'JWT', 'alg' => self::$algorithm]);
        $payload = json_encode([
            'sub' => $userId,
            'iat' => time(),
            'exp' => time() + 3600, // 1 heure d'expiration
            'jti' => bin2hex(random_bytes(16)) // Identifiant unique
        ]);
        
        $base64Header = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($header));
        $base64Payload = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($payload));
        
        $signature = hash_hmac('sha256', $base64Header . "." . $base64Payload, self::$secretKey, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        return $base64Header . "." . $base64Payload . "." . $base64Signature;
    }
    
    public static function validateResetToken($token) {
        $parts = explode('.', $token);
        if (count($parts) !== 3) return false;
        
        $signature = hash_hmac('sha256', $parts[0] . "." . $parts[1], self::$secretKey, true);
        $base64Signature = str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($signature));
        
        if ($base64Signature !== $parts[2]) return false;
        
        $payload = json_decode(base64_decode($parts[1]), true);
        if (!$payload) return false;
        
        if ($payload['exp'] < time()) return false;
        
        return $payload;
    }
}
