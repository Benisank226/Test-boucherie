// payment-success.js
document.addEventListener('DOMContentLoaded', function() {
    // Afficher les détails de la transaction
    const urlParams = new URLSearchParams(window.location.search);
    const transactionId = urlParams.get('transaction');
    if (transactionId) {
        document.getElementById('transaction-id').textContent = transactionId;
    }
    
    // Charger les articles depuis le localStorage ou l'API
    const cart = JSON.parse(localStorage.getItem('boucherie_last_order')) || [];
    displayOrderItems(cart);
    
    // Animation de confettis
    createConfetti();
});

function displayOrderItems(items) {
    const container = document.getElementById('success-items');
    const totalElement = document.getElementById('success-total');
    
    if (!container || !totalElement) return;
    
    let subtotal = 0;
    
    container.innerHTML = items.map(item => {
        subtotal += item.price * item.quantity;
        return `
            <div class="success-item">
                <span>${item.name} x${item.quantity}</span>
                <span>${formatPrice(item.price * item.quantity)} FCFA</span>
            </div>
        `;
    }).join('');
    
    const total = subtotal + 2000; // Ajouter les frais de livraison
    totalElement.textContent = formatPrice(total) + ' FCFA';
}

function formatPrice(price) {
    return new Intl.NumberFormat('fr-FR').format(price);
}

function createConfetti() {
    const colors = ['#8B0000', '#A52A2A', '#28a745', '#ffc107', '#17a2b8'];
    
    for (let i = 0; i < 50; i++) {
        const confetti = document.createElement('div');
        confetti.className = 'confetti';
        confetti.style.left = Math.random() * 100 + 'vw';
        confetti.style.backgroundColor = colors[Math.floor(Math.random() * colors.length)];
        confetti.style.animationDelay = Math.random() * 3 + 's';
        confetti.style.width = Math.random() * 10 + 5 + 'px';
        confetti.style.height = Math.random() * 10 + 5 + 'px';
        document.body.appendChild(confetti);
    }
}