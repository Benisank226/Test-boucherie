// products.js - Version corrigée et optimisée

document.addEventListener('DOMContentLoaded', function() {
    // Vérification des éléments requis
    if (!document.getElementById('products-container')) {
        console.error('Le conteneur des produits est introuvable');
        return;
    }

    // Données des produits avec images par défaut
    const productsData = [
        {
            id: 1,
            name: "Filet de Bœuf",
            category: "boeuf",
            price: 4500,
            description: "Filet de bœuf tendre et savoureux, parfait pour les grillades. Provenance locale, viande maturée 21 jours.",
            images: ["images/boeuf1.jpg", "images/boeuf2.jpg"],
            stock: 15
        },
        {
        id: 2,
            name: "Côtelette d'Agneau",
            category: "mouton",
            price: 3800,
            description: "Côtelette d'agneau fraîche, idéale pour les brochettes ou la cuisson au four. Saveur riche et texture tendre.",
            images: ["images/mouton1.jpg", "images/mouton2.jpg"],
            stock: 10
        },
        {
            id: 3,
            name: "Poulet Fermier Entier",
            category: "poulet",
            price: 6000,
            description: "Poulet fermier élevé en plein air, chair ferme et goût authentique. Poids moyen 1.5kg.",
            images: ["images/poulet1.jpg", "images/poulet2.jpg"],
            stock: 8
        },
        {
            id: 4,
            name: "Saucisses Maison",
            category: "special",
            price: 2500,
            description: "Saucisses artisanales préparées selon notre recette secrète. Parfait pour le barbecue.",
            images: ["images/special1.jpg", "images/special2.jpg"],
            stock: 20
        },
        {
            id: 5,
            name: "Rôti de Bœuf",
            category: "boeuf",
            price: 5200,
            description: "Rôti de bœuf premium pour les occasions spéciales. Viande persillée de première qualité.",
            images: ["images/boeuf3.jpg", "images/boeuf4.jpg"],
            stock: 12
        },
        {
            id: 6,
            name: "Gigot d'Agneau",
            category: "mouton",
            price: 7500,
            description: "Gigot d'agneau entier pour les repas familiaux. Saveur délicate et texture fondante.",
            images: ["images/mouton3.jpg", "images/mouton4.jpg"],
            stock: 6
        } 
    ];

    // Références aux éléments DOM avec vérification
    const getElement = (id) => {
        const el = document.getElementById(id);
        if (!el) console.warn(`Élément #${id} introuvable`);
        return el;
    };

    const productsContainer = getElement('products-container');
    const searchInput = getElement('search-input');
    const searchBtn = getElement('search-btn');
    const categoryFilter = getElement('category-filter');
    const productModal = getElement('product-modal');

    if (!productsContainer) return;

    // Variables d'état
    let currentProducts = [];
    let selectedProduct = null;

    // Initialisation
    try {
        currentProducts = [...productsData];
        renderProducts(currentProducts);
        setupEventListeners();
    } catch (error) {
        console.error('Erreur lors de l\'initialisation:', error);
        showErrorState();
    }

    function showErrorState() {
        productsContainer.innerHTML = `
            <div class="error-state" style="grid-column: 1/-1; text-align: center; padding: 2rem;">
                <i class="fas fa-exclamation-triangle" style="color: #8B0000; font-size: 2rem;"></i>
                <h3>Erreur de chargement</h3>
                <p>Nous rencontrons des difficultés techniques. Veuillez réessayer plus tard.</p>
                <button onclick="window.location.reload()" class="btn">Recharger</button>
            </div>
        `;
    }

    function renderProducts(products) {
        try {
            if (!products || !Array.isArray(products)) {
                throw new Error('Données de produits invalides');
            }

            if (products.length === 0) {
                productsContainer.innerHTML = `
                    <div class="no-results">
                        <i class="fas fa-search"></i>
                        <h3>Aucun produit trouvé</h3>
                        <p>Essayez de modifier vos critères de recherche</p>
                    </div>
                `;
                return;
            }

            productsContainer.innerHTML = products.map(product => `
                <div class="product-card" data-id="${product.id}">
                    <div class="product-image">
                        <img src="${product.images?.[0] || 'images/default.jpg'}" 
                             alt="${product.name}" 
                             onerror="this.src='images/default.jpg'">
                    </div>
                    <div class="product-info">
                        <h3>${escapeHTML(product.name)}</h3>
                        <p class="product-category">${getCategoryName(product.category)}</p>
                        <p class="product-price">${formatPrice(product.price)} FCFA</p>
                        <div class="product-description">
                            <p>${truncateText(escapeHTML(product.description), 100)}</p>
                        </div>
                        <div class="product-actions">
                            <button class="view-details" data-id="${product.id}">
                                <i class="fas fa-eye"></i> Détails
                            </button>
                            <button class="quick-add" data-id="${product.id}" ${product.stock <= 0 ? 'disabled' : ''}>
                                <i class="fas fa-cart-plus"></i> ${product.stock <= 0 ? 'Rupture' : 'Ajouter'}
                            </button>
                        </div>
                        ${product.stock <= 5 && product.stock > 0 ? 
                          `<div class="stock-warning">Plus que ${product.stock} disponible(s)</div>` : ''}
                    </div>
                </div>
            `).join('');

        } catch (error) {
            console.error('Erreur lors du rendu des produits:', error);
            showErrorState();
        }
    }

    function setupEventListeners() {
        // Délégation d'événements pour meilleure performance
        document.addEventListener('click', function(e) {
            const target = e.target;
            const productCard = target.closest('.product-card');
            const viewDetailsBtn = target.closest('.view-details');
            const quickAddBtn = target.closest('.quick-add');

            if (productCard && !viewDetailsBtn && !quickAddBtn) {
                const productId = parseInt(productCard.dataset.id);
                showProductDetails(productId);
            }

            if (viewDetailsBtn) {
                e.stopPropagation();
                const productId = parseInt(viewDetailsBtn.dataset.id);
                showProductDetails(productId);
            }

            if (quickAddBtn && !quickAddBtn.disabled) {
                e.stopPropagation();
                const productId = parseInt(quickAddBtn.dataset.id);
                addToCart(productId, 1);
                showNotification(`<i class="fas fa-check"></i> Produit ajouté au panier`, 'success');
            }
        });

        // Recherche et filtres
        if (searchBtn && searchInput) {
            searchBtn.addEventListener('click', filterProducts);
            searchInput.addEventListener('keyup', function(e) {
                if (e.key === 'Enter') filterProducts();
            });
        }

        if (categoryFilter) {
            categoryFilter.addEventListener('change', filterProducts);
        }

        // Modal
        const closeModal = document.querySelector('.close-modal');
        if (closeModal) {
            closeModal.addEventListener('click', () => {
                productModal.style.display = 'none';
            });
        }

        window.addEventListener('click', function(e) {
            if (e.target === productModal) {
                productModal.style.display = 'none';
            }
        });

        // Gestion quantité
        const setupQuantityControls = () => {
            const minusBtn = document.querySelector('.quantity-btn.minus');
            const plusBtn = document.querySelector('.quantity-btn.plus');
            const quantityInput = document.getElementById('product-quantity');

            if (minusBtn && plusBtn && quantityInput) {
                minusBtn.addEventListener('click', () => {
                    let value = parseInt(quantityInput.value) || 1;
                    quantityInput.value = Math.max(1, value - 1);
                });

                plusBtn.addEventListener('click', () => {
                    let value = parseInt(quantityInput.value) || 1;
                    quantityInput.value = value + 1;
                });

                quantityInput.addEventListener('change', function() {
                    this.value = Math.max(1, parseInt(this.value) || 1);
                });
            }
        };

        setupQuantityControls();

        // Ajout au panier depuis modal
        const addToCartBtn = document.getElementById('add-to-cart-btn');
        if (addToCartBtn) {
            addToCartBtn.addEventListener('click', function() {
                if (!selectedProduct) return;
                
                const quantityInput = document.getElementById('product-quantity');
                const quantity = parseInt(quantityInput?.value) || 1;
                
                addToCart(selectedProduct.id, quantity);
                productModal.style.display = 'none';
                
                showNotification(
                    `<i class="fas fa-check-circle"></i> ${quantity} ${escapeHTML(selectedProduct.name)} ajouté(s) au panier`, 
                    'success'
                );
            });
        }
    }

    function filterProducts() {
        try {
            const searchTerm = (searchInput?.value || '').toLowerCase();
            const category = categoryFilter?.value || 'all';

            currentProducts = productsData.filter(product => {
                const matchesSearch = product.name.toLowerCase().includes(searchTerm) || 
                                    product.description.toLowerCase().includes(searchTerm);
                const matchesCategory = category === 'all' || product.category === category;
                
                return matchesSearch && matchesCategory;
            });

            renderProducts(currentProducts);
        } catch (error) {
            console.error('Erreur lors du filtrage:', error);
        }
    }

    function showProductDetails(productId) {
        try {
            selectedProduct = productsData.find(p => p.id === productId);
            if (!selectedProduct || !productModal) return;

            // Mise à jour du modal
            setModalContent('modal-product-name', selectedProduct.name);
            setModalContent('modal-product-category', getCategoryName(selectedProduct.category));
            setModalContent('modal-product-price', formatPrice(selectedProduct.price));
            setModalContent('modal-product-description', selectedProduct.description);

            const mainImage = document.getElementById('modal-product-image');
            if (mainImage) {
                mainImage.src = selectedProduct.images?.[0] || 'images/default.jpg';
                mainImage.onerror = function() {
                    this.src = 'images/default.jpg';
                };
            }

            // Miniatures
            const thumbnailsContainer = document.getElementById('thumbnails');
            if (thumbnailsContainer) {
                thumbnailsContainer.innerHTML = '';
                
                (selectedProduct.images || ['images/default.jpg']).forEach((img, index) => {
                    const thumbnail = document.createElement('img');
                    thumbnail.src = img;
                    thumbnail.alt = `${selectedProduct.name} - Vue ${index + 1}`;
                    if (index === 0) thumbnail.classList.add('active');
                    
                    thumbnail.onerror = function() {
                        this.src = 'images/default.jpg';
                    };
                    
                    thumbnail.addEventListener('click', function() {
                        if (mainImage) mainImage.src = this.src;
                        document.querySelectorAll('#thumbnails img').forEach(t => t.classList.remove('active'));
                        this.classList.add('active');
                    });
                    
                    thumbnailsContainer.appendChild(thumbnail);
                });
            }

            // Quantité et stock
            const quantityInput = document.getElementById('product-quantity');
            if (quantityInput) {
                quantityInput.value = 1;
                quantityInput.max = selectedProduct.stock || 10;
            }

            const addToCartBtn = document.getElementById('add-to-cart-btn');
            if (addToCartBtn) {
                addToCartBtn.disabled = selectedProduct.stock <= 0;
                addToCartBtn.textContent = selectedProduct.stock <= 0 ? 'Rupture de stock' : 'Ajouter au panier';
            }

            productModal.style.display = 'block';
        } catch (error) {
            console.error('Erreur lors de l\'affichage des détails:', error);
            showNotification('Impossible d\'afficher les détails du produit', 'error');
        }
    }

    function addToCart(productId, quantity) {
        try {
            const product = productsData.find(p => p.id === productId);
            if (!product || quantity < 1) return;

            let cart = [];
            try {
                const cartData = localStorage.getItem('boucherie_cart');
                cart = cartData ? JSON.parse(cartData) : [];
            } catch (e) {
                console.error('Erreur de lecture du panier:', e);
            }

            const existingItem = cart.find(item => item.id === productId);
            
            if (existingItem) {
                existingItem.quantity += quantity;
            } else {
                cart.push({
                    id: product.id,
                    name: product.name,
                    price: product.price,
                    quantity: quantity,
                    image: product.images?.[0] || 'images/default.jpg'
                });
            }
            
            localStorage.setItem('boucherie_cart', JSON.stringify(cart));
            updateCartCount();
        } catch (error) {
            console.error('Erreur lors de l\'ajout au panier:', error);
            showNotification('Erreur lors de l\'ajout au panier', 'error');
        }
    }

    function updateCartCount() {
        try {
            const cartCountElements = document.querySelectorAll('#cart-count, .cart-count');
            const cart = JSON.parse(localStorage.getItem('boucherie_cart')) || [];
            const total = cart.reduce((sum, item) => sum + (item.quantity || 0), 0);

            cartCountElements.forEach(el => {
                if (el) el.textContent = total;
            });
        } catch (error) {
            console.error('Erreur de mise à jour du compteur:', error);
        }
    }

    // Fonctions utilitaires
    function setModalContent(elementId, content) {
        const element = document.getElementById(elementId);
        if (element) element.textContent = content;
    }

    function formatPrice(price) {
        return isNaN(price) ? 'N/A' : new Intl.NumberFormat('fr-FR').format(price);
    }

    function getCategoryName(category) {
        const categories = {
            'boeuf': 'Bœuf',
            'mouton': 'Mouton',
            'poulet': 'Poulet',
            'special': 'Spécialité'
        };
        return categories[category] || category;
    }

    function escapeHTML(str) {
        if (!str) return '';
        return str.toString()
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function truncateText(text, maxLength) {
        if (!text) return '';
        return text.length > maxLength ? text.substring(0, maxLength) + '...' : text;
    }
});

// Fonction accessible globalement pour les images
window.handleImageError = function(img) {
    img.src = 'images/default.jpg';
    img.onerror = null;
};