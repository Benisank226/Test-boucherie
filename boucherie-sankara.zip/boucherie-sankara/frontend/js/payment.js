document.addEventListener('DOMContentLoaded', function() {
    // Vérifier le panier
    const cart = JSON.parse(localStorage.getItem('boucherie_cart')) || [];
    if (cart.length === 0) {
        window.location.href = 'panier.html';
        return;
    }

    // Éléments du DOM
    const paymentMethods = document.querySelectorAll('.payment-method');
    const paymentForm = document.getElementById('payment-form');
    const paymentMethodInput = document.getElementById('payment-method');
    const orderItemsContainer = document.getElementById('order-items');
    const subtotalElement = document.getElementById('subtotal');
    const totalElement = document.getElementById('total');
    const notification = document.getElementById('payment-notification');

    // Afficher les articles du panier
    displayOrderItems(cart);

    // Calculer et afficher les totaux
    calculateTotals(cart);

    // Gestion des méthodes de paiement
    paymentMethods.forEach(method => {
        method.addEventListener('click', function() {
            paymentMethods.forEach(m => m.classList.remove('active'));
            this.classList.add('active');
            paymentMethodInput.value = this.dataset.method;
        });
    });

    // Soumission du formulaire de paiement
    if (paymentForm) {
        paymentForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const form = e.target;
            const submitButton = form.querySelector('button[type="submit"]');
            const phoneNumber = '+226' + form.phone.value.trim().replace(/\s/g, '');
            const paymentMethod = form.payment_method.value;
            
            // Validation
            if (!phoneNumber.match(/^\+226[0-9]{8}$/)) {
                showNotification('Veuillez entrer un numéro valide', 'error');
                return;
            }
            
            // Désactiver le bouton pendant le traitement
            form.classList.add('loading');
            submitButton.disabled = true;
            
            try {
                // Simuler l'initialisation du paiement
                const paymentData = {
                    method: paymentMethod,
                    phone: phoneNumber,
                    amount: getCartTotal(cart),
                    items: cart.map(item => ({
                        id: item.id,
                        name: item.name,
                        quantity: item.quantity,
                        price: item.price
                    }))
                };
                
                // En production, remplacer par un appel API réel
                const paymentResponse = await mockInitPayment(paymentData);
                
                // Simuler la vérification du paiement
                const verification = await mockVerifyPayment(paymentResponse.transactionId);
                
                if (verification.success) {
                    // Paiement réussi - vider le panier et rediriger
                    localStorage.removeItem('boucherie_cart');
                    window.location.href = 'payment-success.html?transaction=' + paymentResponse.transactionId;
                } else {
                    throw new Error('Paiement échoué ou annulé');
                }
            } catch (error) {
                console.error('Erreur de paiement:', error);
                showNotification(error.message || 'Erreur lors du traitement du paiement', 'error');
            } finally {
                form.classList.remove('loading');
                submitButton.disabled = false;
            }
        });
    }

    // Fonctions d'affichage
    function displayOrderItems(cartItems) {
        if (!orderItemsContainer) return;
        
        orderItemsContainer.innerHTML = cartItems.map(item => `
            <div class="order-item">
                <span>${item.name} x${item.quantity}</span>
                <span>${formatPrice(item.price * item.quantity)} FCFA</span>
            </div>
        `).join('');
    }

    function calculateTotals(cartItems) {
        const subtotal = cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0);
        const delivery = 2000; // Frais de livraison fixes
        const total = subtotal + delivery;
        
        if (subtotalElement) subtotalElement.textContent = formatPrice(subtotal) + ' FCFA';
        if (totalElement) totalElement.textContent = formatPrice(total) + ' FCFA';
    }

    function getCartTotal(cartItems) {
        return cartItems.reduce((sum, item) => sum + (item.price * item.quantity), 0) + 2000;
    }

    // Fonctions de simulation API
    async function mockInitPayment(paymentData) {
        // Simuler un délai réseau
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // En production, utiliser une requête fetch vers votre backend
        // const response = await fetch('/api/payment/init', {
        //     method: 'POST',
        //     headers: { 'Content-Type': 'application/json' },
        //     body: JSON.stringify(paymentData)
        // });
        // return await response.json();
        
        return {
            success: true,
            transactionId: 'TX' + Math.random().toString(36).substr(2, 9).toUpperCase(),
            paymentUrl: '#'
        };
    }

    async function mockVerifyPayment(transactionId) {
        await new Promise(resolve => setTimeout(resolve, 2000));
        
        // Simuler 80% de chance de succès
        const isSuccess = Math.random() > 0.2;
        
        return {
            success: isSuccess,
            transactionId: transactionId,
            message: isSuccess ? 'Paiement confirmé' : 'Paiement refusé'
        };
    }

    // Fonctions utilitaires
    function formatPrice(price) {
        return new Intl.NumberFormat('fr-FR').format(price);
    }

    function showNotification(message, type = 'success') {
        if (!notification) return;
        
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        notification.className = `payment-notification show ${type}`;
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 5000);
    }
});