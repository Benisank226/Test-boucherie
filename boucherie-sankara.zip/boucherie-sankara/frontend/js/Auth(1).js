// auth.js - Gestion de l'authentification

document.addEventListener('DOMContentLoaded', function() {
    // Éléments du formulaire
    const loginForm = document.getElementById('loginForm');
    const passwordInput = document.getElementById('password');
    const togglePassword = document.querySelector('.toggle-password');
    const notification = document.getElementById('notification');

    // Afficher/masquer le mot de passe
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    }

    // Soumission du formulaire
    if (loginForm) {
        loginForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const form = e.target;
            const submitButton = form.querySelector('button[type="submit"]');
            const email = form.email.value.trim();
            const password = form.password.value.trim();
            
            // Validation basique
            if (!email || !password) {
                showNotification('Veuillez remplir tous les champs', 'error');
                return;
            }
            
            // Désactiver le bouton pendant la requête 
            form.classList.add('loading');
            submitButton.disabled = true;
            
            try {
                // Envoyer les données au backend
                const response = await fetch('backend/api/auth/login.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        email: email,
                        password: password
                    })
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    // Connexion réussie
                    localStorage.setItem('boucherie_token', data.token);
                    localStorage.setItem('boucherie_user', JSON.stringify(data.user));
                    
                    showNotification('Connexion réussie !', 'success');
                    
                    // Redirection après un court délai
                    setTimeout(() => {
                        const redirectUrl = getRedirectUrl() || 'compte.html';
                        window.location.href = redirectUrl;
                    }, 1500);
                } else {
                    // Erreur de connexion
                    throw new Error(data.message || 'Erreur de connexion');
                }
            } catch (error) {
                console.error('Erreur:', error);
                showNotification(error.message, 'error');
            } finally {
                form.classList.remove('loading');
                submitButton.disabled = false;
            }
        });
    }

    // Fonction pour afficher les notifications
    function showNotification(message, type = 'success') {
        if (!notification) return;
        
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        notification.className = `auth-notification show ${type}`;
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 5000);
    }

    // Récupérer l'URL de redirection depuis les paramètres GET
    function getRedirectUrl() {
        const params = new URLSearchParams(window.location.search);
        return params.get('redirect');
    }

    // Vérifier si l'utilisateur est déjà connecté
    function checkAuth() {
        const token = localStorage.getItem('boucherie_token');
        const user = localStorage.getItem('boucherie_user');
        
        if (token && user) {
            const redirectUrl = getRedirectUrl();
            if (redirectUrl) {
                window.location.href = redirectUrl;
            } else {
                window.location.href = 'compte.html';
            }
        }
    }
    
    // Vérification initiale
    checkAuth();
});