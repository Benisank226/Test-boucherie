<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../lib/token.php';

// Simuler une base utilisateurs
$users = [
    'client@example.com' => [
        'id' => 1,
        'password' => '$2y$10$...' // Mot de passe haché
    ]
];

$data = json_decode(file_get_contents('php://input'), true);

if (empty($data['email'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Email requis']);
    exit;
}

$email = strtolower(trim($data['email']));

// Vérifier si l'utilisateur existe
if (!array_key_exists($email, $users)) {
    // Ne pas révéler que l'email n'existe pas pour des raisons de sécurité
    sleep(1); // Délai pour éviter l'énumération d'emails
    http_response_code(200);
    echo json_encode(['message' => 'Si cet email existe, un lien a été envoyé']);
    exit;
}

// Générer un token sécurisé
$token = Token::generateResetToken($users[$email]['id']);

// Enregistrer le token en base (simulé)
file_put_contents(
    'tokens.json',
    json_encode([$token => [
        'user_id' => $users[$email]['id'],
        'email' => $email,
        'expires' => time() + 3600 // Expire dans 1h
    ]]),
    FILE_APPEND
);

// Envoyer l'email (simulation)
$resetLink = "https://votre-site.com/password-reset-form.html?token=$token";

// En production, utiliser une bibliothèque comme PHPMailer
// mail($email, 'Réinitialisation de mot de passe', "Cliquez ici: $resetLink");

http_response_code(200);
echo json_encode([
    'message' => 'Si cet email existe, un lien a été envoyé',
    'token' => $token // À supprimer en production - seulement pour le débogage
]);
