<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../lib/jwt.php';

// Simuler une base de données (à remplacer par une vraie DB)
$valid_users = [
    'client@example.com' => [
        'password' => password_hash('motdepasse123', PASSWORD_DEFAULT),
        'id' => 1,
        'nom' => 'Client',
        'prenom' => 'Test',
        'telephone' => '661234567'
    ]
];

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['email']) || !isset($data['password'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Email et mot de passe requis']);
    exit;
}

$email = $data['email'];
$password = $data['password'];

// Vérification de l'utilisateur
if (!array_key_exists($email, $valid_users)) {
    http_response_code(401);
    echo json_encode(['message' => 'Email ou mot de passe incorrect']);
    exit;
}

$user = $valid_users[$email];

// Vérification du mot de passe
if (!password_verify($password, $user['password'])) {
    http_response_code(401);
    echo json_encode(['message' => 'Email ou mot de passe incorrect']);
    exit;
}

// Création du token JWT
$token = JWT::encode([
    'sub' => $user['id'],
    'email' => $email,
    'exp' => time() + (60 * 60 * 24) // Expire dans 24h
], 'votre_cle_secrete_super_securisee');

// Réponse avec le token et les infos utilisateur
echo json_encode([
    'token' => $token,
    'user' => [
        'id' => $user['id'],
        'nom' => $user['nom'],
        'prenom' => $user['prenom'],
        'email' => $email,
        'telephone' => $user['telephone']
    ]
]);

