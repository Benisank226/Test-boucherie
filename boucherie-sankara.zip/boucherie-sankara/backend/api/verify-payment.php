<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

$transactionId = $_GET['transactionId'] ?? '';

if (empty($transactionId)) {
    http_response_code(400);
    echo json_encode(['error' => 'Transaction ID manquant']);
    exit;
}

// Simuler la vérification du statut
// En production, vous interrogeriez l'API du service de paiement
$status = (rand(1, 10) > 2) ? 'completed' : 'failed'; // 80% de succès

$response = [
    'success' => $status === 'completed',
    'transactionId' => $transactionId,
    'status' => $status,
    'message' => $status === 'completed' ? 'Paiement confirmé' : 'Paiement échoué'
];

// Mettre à jour la transaction (simulé)
file_put_contents('transactions.log', json_encode([
    'transactionId' => $transactionId,
    'status' => $status,
    'verified_at' => date('Y-m-d H:i:s')
]) . PHP_EOL, FILE_APPEND);

echo json_encode($response);