// auth.js - Version corrigée et améliorée

document.addEventListener('DOMContentLoaded', function() {
    // Initialisation des éléments
    const cartLink = document.getElementById('cart-link');
    const accountLink = document.getElementById('account-link');
    const cartCount = document.getElementById('cart-count');
    
    // Ajout du CSS pour les notifications directement dans le JS
    addNotificationStyles();
    
    // Vérifier si l'utilisateur est connecté de manière plus robuste
    function checkAuth() {
        try {
            const token = localStorage.getItem('boucherie_token');
            return token !== null && token !== undefined;
        } catch (e) {
            console.error('Erreur d\'accès au localStorage:', e);
            return false;
        }
    }
    
    // Mettre à jour le compteur du panier avec gestion d'erreur
    function updateCartCount() {
        try {
            const cartData = localStorage.getItem('boucherie_cart');
            const cart = cartData ? JSON.parse(cartData) : [];
            const total = Array.isArray(cart) ?
                cart.reduce((total, item) => total + (item.quantity || 0), 0) :
                0;
            cartCount.textContent = total;
        } catch (e) {
            console.error('Erreur de lecture du panier:', e);
            cartCount.textContent = '0';
        }
    }
    
    // Gestion du clic sur le panier
    if (cartLink) {
        cartLink.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (checkAuth()) {
                window.location.href = 'panier.html';
            } else {
                showNotification(
                    '<i class="fas fa-info-circle"></i> Veuillez vous connecter pour accéder à votre panier',
                    'info'
                );
                setTimeout(() => {
                    const currentUrl = window.location.pathname;
                    window.location.href = `login.html?redirect=${encodeURIComponent(currentUrl)}`;
                }, 2500);
            }
        });
    }
    
    // Gestion du clic sur le compte
    if (accountLink) {
        accountLink.addEventListener('click', function(e) {
            e.preventDefault();
            window.location.href = checkAuth() ? 'compte.html' : 'login.html';
        });
    }
    
    // Initialisation
    updateCartCount();
    
    // Fonction pour ajouter les styles des notifications
    function addNotificationStyles() {
        const style = document.createElement('style');
        style.textContent = `
            .notification {
                position: fixed;
                top: 20px;
                right: 20px;
                padding: 15px 25px;
                border-radius: 5px;
                color: white;
                box-shadow: 0 4px 12px rgba(0,0,0,0.15);
                z-index: 1000;
                display: flex;
                align-items: center;
                transition: all 0.3s ease;
                opacity: 0;
                transform: translateY(-20px);
                animation: fadeIn 0.3s forwards;
            }
            
            .notification i {
                margin-right: 10px;
                font-size: 1.2em;
            }
            
            .notification.success {
                background-color: #28a745;
            }
            
            .notification.error {
                background-color: #dc3545;
            }
            
            .notification.info {
                background-color: #17a2b8;
            }
            
            .notification.warning {
                background-color: #ffc107;
                color: #212529;
            }
            
            .notification.fade-out {
                animation: fadeOut 0.3s forwards;
            }
            
            @keyframes fadeIn {
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }
            
            @keyframes fadeOut {
                to {
                    opacity: 0;
                    transform: translateY(-20px);
                }
            }
        `;
        document.head.appendChild(style);
    }
});

// Fonction de notification améliorée
function showNotification(message, type = 'success') {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.innerHTML = message;
    
    // Ajout au DOM
    document.body.appendChild(notification);
    
    // Affichage
    setTimeout(() => {
        notification.style.opacity = '1';
        notification.style.transform = 'translateY(0)';
    }, 10);
    
    // Disparition après 3 secondes
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateY(-20px)';
        setTimeout(() => {
            notification.remove();
        }, 300);
    }, 3000);
}
