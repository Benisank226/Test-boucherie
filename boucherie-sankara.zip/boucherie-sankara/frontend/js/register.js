// register.js - Gestion de l'inscription

document.addEventListener('DOMContentLoaded', function() {
    // Références aux éléments
    const registerForm = document.getElementById('registerForm');
    const passwordInput = document.getElementById('password');
    const confirmPasswordInput = document.getElementById('confirmPassword');
    const togglePasswordBtns = document.querySelectorAll('.toggle-password');
    const notification = document.getElementById('notification');
    const strengthBar = document.querySelector('.strength-bar');
    const strengthText = document.querySelector('.strength-text');
    const passwordHints = document.querySelectorAll('.password-hints li');

    // Afficher/masquer les mots de passe
    togglePasswordBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const input = this.parentElement.querySelector('input');
            const type = input.getAttribute('type') === 'password' ? 'text' : 'password';
            input.setAttribute('type', type);
            this.querySelector('i').classList.toggle('fa-eye-slash');
        });
    });

    // Validation en temps réel du mot de passe
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            validatePassword(this.value);
            validateConfirmPassword();
        });
    }

    if (confirmPasswordInput) {
        confirmPasswordInput.addEventListener('input', validateConfirmPassword);
    }

    // Validation du formulaire
    if (registerForm) {
        registerForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            // Valider tous les champs
            const isValid = validateForm();
            
            if (isValid) {
                const form = e.target;
                const submitButton = form.querySelector('button[type="submit"]');
                
                // Désactiver le bouton pendant l'envoi
                form.classList.add('loading');
                submitButton.disabled = true;
                
                try {
                    // Préparer les données
                    const formData = {
                        lastname: form.lastname.value.trim(),
                        firstname: form.firstname.value.trim(),
                        email: form.email.value.trim(),
                        phone: '+226' + form.phone.value.trim().replace(/\s/g, ''),
                        password: form.password.value
                    };
                    
                    // Envoyer au backend
                    const response = await fetch('backend/api/auth/register.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json'
                        },
                        body: JSON.stringify(formData)
                    });
                    
                    const data = await response.json();
                    
                    if (response.ok) {
                        // Inscription réussie
                        showNotification('Inscription réussie ! Un email de confirmation a été envoyé.', 'success');
                        
                        // Redirection après délai
                        setTimeout(() => {
                            window.location.href = 'login.html';
                        }, 3000);
                    } else {
                        // Erreur d'inscription
                        throw new Error(data.message || 'Erreur lors de l\'inscription');
                    }
                } catch (error) {
                    console.error('Erreur:', error);
                    showNotification(error.message, 'error');
                } finally {
                    form.classList.remove('loading');
                    submitButton.disabled = false;
                }
            }
        });
    }

    // Fonctions de validation
    function validateForm() {
        let isValid = true;
        
        // Valider chaque champ
        isValid = validateField('lastname', 'Veuillez entrer votre nom') && isValid;
        isValid = validateField('firstname', 'Veuillez entrer votre prénom') && isValid;
        isValid = validateEmail() && isValid;
        isValid = validatePhone() && isValid;
        isValid = validatePassword(passwordInput.value) && isValid;
        isValid = validateConfirmPassword() && isValid;
        isValid = validateTerms() && isValid;
        
        return isValid;
    }

    function validateField(fieldId, errorMessage) {
        const field = document.getElementById(fieldId);
        const errorElement = document.getElementById(`${fieldId}-error`);
        
        if (!field.value.trim()) {
            showError(field, errorElement, errorMessage);
            return false;
        } else {
            clearError(field, errorElement);
            return true;
        }
    }

    function validateEmail() {
        const email = document.getElementById('email');
        const errorElement = document.getElementById('email-error');
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        
        if (!email.value.trim()) {
            showError(email, errorElement, 'Veuillez entrer votre email');
            return false;
        } else if (!emailRegex.test(email.value)) {
            showError(email, errorElement, 'Veuillez entrer un email valide');
            return false;
        } else {
            clearError(email, errorElement);
            return true;
        }
    }

    function validatePhone() {
        const phone = document.getElementById('phone');
        const errorElement = document.getElementById('phone-error');
        const phoneRegex = /^[0-9\s]{8,}$/;
        
        if (!phone.value.trim()) {
            showError(phone, errorElement, 'Veuillez entrer votre numéro');
            return false;
        } else if (!phoneRegex.test(phone.value)) {
            showError(phone, errorElement, 'Numéro invalide (ex: 66 12 34 56)');
            return false;
        } else {
            clearError(phone, errorElement);
            return true;
        }
    }

    function validatePassword(password) {
        const errorElement = document.getElementById('password-error');
        
        // Critères de validation
        const hasMinLength = password.length >= 8;
        const hasUpperCase = /[A-Z]/.test(password);
        const hasNumber = /[0-9]/.test(password);
        const hasSpecialChar = /[!@#$%^&*(),.?":{}|<>]/.test(password);
        
        // Mettre à jour les indications
        passwordHints[0].classList.toggle('valid', hasMinLength);
        passwordHints[1].classList.toggle('valid', hasUpperCase);
        passwordHints[2].classList.toggle('valid', hasNumber);
        passwordHints[3].classList.toggle('valid', hasSpecialChar);
        
        // Calculer la force
        let strength = 0;
        if (hasMinLength) strength++;
        if (hasUpperCase) strength++;
        if (hasNumber) strength++;
        if (hasSpecialChar) strength++;
        
        // Mettre à jour l'affichage
        updateStrengthMeter(strength);
        
        if (!password) {
            showError(passwordInput, errorElement, 'Veuillez entrer un mot de passe');
            return false;
        } else if (strength < 3) {
            showError(passwordInput, errorElement, 'Le mot de passe est trop faible');
            return false;
        } else {
            clearError(passwordInput, errorElement);
            return true;
        }
    }

    function validateConfirmPassword() {
        const errorElement = document.getElementById('confirmPassword-error');
        const password = passwordInput.value;
        const confirmPassword = confirmPasswordInput.value;
        
        if (!confirmPassword) {
            showError(confirmPasswordInput, errorElement, 'Veuillez confirmer le mot de passe');
            return false;
        } else if (password !== confirmPassword) {
            showError(confirmPasswordInput, errorElement, 'Les mots de passe ne correspondent pas');
            return false;
        } else {
            clearError(confirmPasswordInput, errorElement);
            return true;
        }
    }

    function validateTerms() {
        const terms = document.getElementById('terms');
        const errorElement = document.getElementById('terms-error');
        
        if (!terms.checked) {
            showError(terms, errorElement, 'Vous devez accepter les conditions');
            return false;
        } else {
            clearError(terms, errorElement);
            return true;
        }
    }

    function updateStrengthMeter(strength) {
        const colors = ['#dc3545', '#ffc107', '#17a2b8', '#28a745'];
        const texts = ['Très faible', 'Faible', 'Moyen', 'Fort'];
        
        strengthBar.style.width = `${(strength / 4) * 100}%`;
        strengthBar.style.backgroundColor = colors[strength - 1] || colors[0];
        strengthText.textContent = texts[strength - 1] || texts[0];
        strengthText.style.color = colors[strength - 1] || colors[0];
    }

    function showError(field, errorElement, message) {
        field.style.borderColor = 'var(--error-color)';
        errorElement.textContent = message;
        errorElement.classList.add('show');
    }

    function clearError(field, errorElement) {
        field.style.borderColor = '';
        errorElement.textContent = '';
        errorElement.classList.remove('show');
    }

    function showNotification(message, type = 'success') {
        if (!notification) return;
        
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        notification.className = `auth-notification show ${type}`;
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 5000);
    }
});