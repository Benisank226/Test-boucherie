document.addEventListener('DOMContentLoaded', function() {
    const resetRequestForm = document.getElementById('resetRequestForm');
    const notification = document.getElementById('notification');

    if (resetRequestForm) {
        resetRequestForm.addEventListener('submit', async function(e) {
            e.preventDefault();
            
            const form = e.target;
            const submitButton = form.querySelector('button[type="submit"]');
            const email = form.email.value.trim();
            
            // Validation
            if (!validateEmail(email)) {
                showError('email-error', 'Veuillez entrer un email valide');
                return;
            }
            
            // Désactiver le bouton pendant la requête
            form.classList.add('loading');
            submitButton.disabled = true;
            
            try {
                const response = await fetch('backend/api/auth/request-reset.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ email: email })
                });
                
                const data = await response.json();
                
                if (response.ok) {
                    showNotification(
                        'Un email de réinitialisation a été envoyé. Vérifiez votre boîte de réception.',
                        'success'
                    );
                    
                    // Redirection après délai
                    setTimeout(() => {
                        window.location.href = 'login.html';
                    }, 5000);
                } else {
                    throw new Error(data.message || 'Erreur lors de la demande');
                }
            } catch (error) {
                console.error('Erreur:', error);
                showNotification(error.message, 'error');
            } finally {
                form.classList.remove('loading');
                submitButton.disabled = false;
            }
        });
    }

    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }

    function showError(elementId, message) {
        const errorElement = document.getElementById(elementId);
        if (errorElement) {
            errorElement.textContent = message;
            errorElement.classList.add('show');
        }
    }

    function showNotification(message, type = 'success') {
        if (!notification) return;
        
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        notification.className = `auth-notification show ${type}`;
        
        setTimeout(() => {
            notification.classList.remove('show');
        }, 5000);
    }
});

