document.addEventListener('DOMContentLoaded', function() {
    // Vérification de l'authentification
    const token = localStorage.getItem('boucherie_token');
    const user = JSON.parse(localStorage.getItem('boucherie_user'));
    
    if (!token || !user) {
        window.location.href = 'login.html';
        return;
    }

    // Éléments du DOM
    const logoutLink = document.getElementById('logout-link');
    const menuLinks = document.querySelectorAll('.account-menu a');
    const sections = document.querySelectorAll('.account-section');
    const profileForm = document.getElementById('profile-form');
    const notificationsForm = document.getElementById('notifications-form');
    const editAvatarBtn = document.getElementById('edit-avatar');
    const avatarModal = document.getElementById('avatar-modal');
    const closeModalBtns = document.querySelectorAll('.close-modal');
    const passwordModal = document.getElementById('password-modal');
    const changePasswordBtn = document.getElementById('change-password-btn');
    const passwordForm = document.getElementById('password-form');
    const notification = document.getElementById('account-notification');
    const addAddressBtn = document.getElementById('add-address-btn');

    // Initialisation
    loadUserData();
    loadOrders();
    loadAddresses();
    updateCartCount();

    // Événements
    if (logoutLink) logoutLink.addEventListener('click', handleLogout);
    menuLinks.forEach(link => link.addEventListener('click', handleMenuNavigation));
    if (profileForm) profileForm.addEventListener('submit', handleProfileUpdate);
    if (notificationsForm) notificationsForm.addEventListener('submit', handleNotificationsUpdate);
    if (editAvatarBtn) editAvatarBtn.addEventListener('click', () => avatarModal.style.display = 'block');
    if (changePasswordBtn) changePasswordBtn.addEventListener('click', () => passwordModal.style.display = 'block');
    if (addAddressBtn) addAddressBtn.addEventListener('click', showAddressForm);
    closeModalBtns.forEach(btn => btn.addEventListener('click', closeModal));
    window.addEventListener('click', closeModalOnOutsideClick);
    if (passwordForm) passwordForm.addEventListener('submit', handlePasswordChange);

    // Fonctions principales
    function loadUserData() {
        if (!user || !profileForm) return;
        
        profileForm.lastname.value = user.lastname || '';
        profileForm.firstname.value = user.firstname || '';
        profileForm.email.value = user.email || '';
        profileForm.phone.value = user.phone ? user.phone.replace('+226', '') : '';
        
        updateUserDisplay();
    }

    function updateUserDisplay() {
        const userNameElement = document.getElementById('user-name');
        const userEmailElement = document.getElementById('user-email');
        const userAvatar = document.getElementById('user-avatar');
        
        if (userNameElement) userNameElement.textContent = `${user.firstname || ''} ${user.lastname || ''}`.trim() || 'Nom Prénom';
        if (userEmailElement) userEmailElement.textContent = user.email || 'email@exemple.com';
        if (userAvatar && user.avatar) userAvatar.src = user.avatar;
    }

    async function loadOrders() {
        const ordersList = document.getElementById('orders-list');
        if (!ordersList) return;
        
        ordersList.innerHTML = createLoadingSpinner();
        
        try {
            const orders = await mockFetchOrders();
            
            if (orders.length === 0) {
                ordersList.innerHTML = createNoOrdersMessage();
                return;
            }
            
            ordersList.innerHTML = orders.map(createOrderCard).join('');
            setupOrderActions();
        } catch (error) {
            console.error('Erreur:', error);
            ordersList.innerHTML = createErrorState();
        }
    }

    async function loadAddresses() {
        const addressesContainer = document.getElementById('addresses-container');
        if (!addressesContainer) return;
        
        try {
            const addresses = await mockFetchAddresses();
            const mainAddress = addresses.find(a => a.is_default) || addresses[0];
            
            if (mainAddress) {
                document.getElementById('main-address').innerHTML = `
                    ${mainAddress.street}<br>
                    ${mainAddress.city}, ${mainAddress.region}<br>
                    ${mainAddress.country}
                `;
            }
        } catch (error) {
            console.error('Erreur:', error);
        }
    }

    // Gestionnaires d'événements
    function handleLogout(e) {
        e.preventDefault();
        localStorage.removeItem('boucherie_token');
        localStorage.removeItem('boucherie_user');
        window.location.href = 'login.html';
    }

    function handleMenuNavigation(e) {
        e.preventDefault();
        const sectionId = this.getAttribute('data-section');
        
        menuLinks.forEach(l => l.classList.remove('active'));
        this.classList.add('active');
        
        sections.forEach(section => {
            section.classList.remove('active');
            if (section.id === `${sectionId}-section`) section.classList.add('active');
        });
        
        if (sectionId === 'orders') loadOrders();
        if (sectionId === 'addresses') loadAddresses();
    }

    async function handleProfileUpdate(e) {
        e.preventDefault();
        const form = e.target;
        const submitButton = form.querySelector('button[type="submit"]');
        
        form.classList.add('loading');
        submitButton.disabled = true;
        
        try {
            const formData = {
                lastname: form.lastname.value.trim(),
                firstname: form.firstname.value.trim(),
                email: form.email.value.trim(),
                phone: '+226' + form.phone.value.trim().replace(/\s/g, '')
            };
            
            await mockUpdateProfile(formData);
            
            Object.assign(user, formData);
            localStorage.setItem('boucherie_user', JSON.stringify(user));
            
            showNotification('Profil mis à jour avec succès', 'success');
            updateUserDisplay();
        } catch (error) {
            console.error('Erreur:', error);
            showNotification(error.message, 'error');
        } finally {
            form.classList.remove('loading');
            submitButton.disabled = false;
        }
    }

    async function handleNotificationsUpdate(e) {
        e.preventDefault();
        const form = e.target;
        const submitButton = form.querySelector('button[type="submit"]');
        
        form.classList.add('loading');
        submitButton.disabled = true;
        
        try {
            await new Promise(resolve => setTimeout(resolve, 1000));
            showNotification('Préférences enregistrées', 'success');
        } catch (error) {
            console.error('Erreur:', error);
            showNotification(error.message, 'error');
        } finally {
            form.classList.remove('loading');
            submitButton.disabled = false;
        }
    }

    async function handlePasswordChange(e) {
        e.preventDefault();
        const form = e.target;
        const submitButton = form.querySelector('button[type="submit"]');
        const currentPassword = form['current-password'].value;
        const newPassword = form['new-password'].value;
        const confirmPassword = form['confirm-password'].value;
        
        if (newPassword !== confirmPassword) {
            showNotification('Les mots de passe ne correspondent pas', 'error');
            return;
        }
        
        if (!validatePassword(newPassword)) {
            showNotification('Le mot de passe doit contenir 8 caractères, une majuscule, un chiffre et un caractère spécial', 'error');
            return;
        }
        
        form.classList.add('loading');
        submitButton.disabled = true;
        
        try {
            await mockChangePassword(currentPassword, newPassword);
            showNotification('Mot de passe mis à jour avec succès', 'success');
            passwordModal.style.display = 'none';
            form.reset();
        } catch (error) {
            console.error('Erreur:', error);
            showNotification(error.message, 'error');
        } finally {
            form.classList.remove('loading');
            submitButton.disabled = false;
        }
    }

    // Fonctions d'interface
    function showAddressForm(address = null) {
        const modal = document.createElement('div');
        modal.className = 'modal';
        modal.innerHTML = createAddressFormHTML(address);
        document.body.appendChild(modal);
        
        modal.querySelector('.close-modal').addEventListener('click', () => modal.remove());
        modal.querySelector('form').addEventListener('submit', async function(e) {
            e.preventDefault();
            const form = e.target;
            const submitButton = form.querySelector('button[type="submit"]');
            
            form.classList.add('loading');
            submitButton.disabled = true;
            
            try {
                await new Promise(resolve => setTimeout(resolve, 1000));
                showNotification(`Adresse ${address ? 'modifiée' : 'ajoutée'} avec succès`, 'success');
                modal.remove();
                loadAddresses();
            } catch (error) {
                console.error('Erreur:', error);
                showNotification(error.message, 'error');
            } finally {
                form.classList.remove('loading');
                submitButton.disabled = false;
            }
        });
    }

    function closeModal() {
        this.closest('.modal').style.display = 'none';
    }

    function closeModalOnOutsideClick(e) {
        if (e.target.classList.contains('modal')) e.target.style.display = 'none';
    }

    function viewOrderDetails(orderId) {
        showNotification(`Détails de la commande #${orderId} (fonctionnalité à venir)`, 'info');
    }

    function reorderItems(orderId) {
        showNotification(`Articles de la commande #${orderId} ajoutés au panier`, 'success');
        updateCartCount();
    }

    function setupOrderActions() {
        document.querySelectorAll('.order-actions .btn').forEach(button => {
            button.addEventListener('click', function() {
                const orderId = this.closest('.order-card').querySelector('.order-id').textContent.replace('Commande #', '');
                if (this.textContent.includes('détails')) viewOrderDetails(orderId);
                if (this.textContent.includes('Commander')) reorderItems(orderId);
            });
        });
    }

    // Fonctions utilitaires
    function validatePassword(password) {
        const re = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
        return re.test(password);
    }

    function updateCartCount() {
        const cartCountElements = document.querySelectorAll('#cart-count, .cart-count');
        const cart = JSON.parse(localStorage.getItem('boucherie_cart')) || [];
        const total = cart.reduce((sum, item) => sum + (item.quantity || 0), 0);
        cartCountElements.forEach(el => el && (el.textContent = total));
    }

    function showNotification(message, type = 'success') {
        if (!notification) return;
        
        notification.innerHTML = `
            <i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
            <span>${message}</span>
        `;
        notification.className = `account-notification show ${type}`;
        
        setTimeout(() => notification.classList.remove('show'), 5000);
    }

    // Templates HTML
    function createLoadingSpinner() {
        return `
            <div class="loading-spinner">
                <div class="spinner"></div>
                <p>Chargement en cours...</p>
            </div>
        `;
    }

    function createNoOrdersMessage() {
        return `
            <div class="no-orders">
                <i class="fas fa-box-open"></i>
                <p>Vous n'avez pas encore passé de commande</p>
                <a href="../produits.html" class="btn btn-primary">Voir nos produits</a>
            </div>
        `;
    }

    function createErrorState() {
        return `
            <div class="error-state">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Une erreur s'est produite</p>
                <button class="btn btn-outline" onclick="location.reload()">Réessayer</button>
            </div>
        `;
    }

    function createOrderCard(order) {
        return `
            <div class="order-card">
                <div class="order-header">
                    <div>
                        <span class="order-id">Commande #${order.id}</span>
                        <span class="order-date">${formatDate(order.date)}</span>
                    </div>
                    <span class="order-status status-${order.status}">${getStatusText(order.status)}</span>
                </div>
                
                <div class="order-details">
                    <div class="order-products">
                        ${order.products.slice(0, 2).map(createProductItem).join('')}
                        ${order.products.length > 2 ? `<p>+ ${order.products.length - 2} autre(s) produit(s)</p>` : ''}
                    </div>
                    
                    <div class="order-summary">
                        ${createOrderSummary(order)}
                    </div>
                </div>
                
                <div class="order-actions">
                    <button class="btn btn-outline">Voir les détails</button>
                    ${order.status === 'delivered' ? `<button class="btn btn-outline">Commander à nouveau</button>` : ''}
                </div>
            </div>
        `;
    }

    function createProductItem(product) {
        return `
            <div class="order-product">
                <div class="product-image">
                    <img src="${product.image}" alt="${product.name}">
                </div>
                <div class="product-info">
                    <h4>${product.name}</h4>
                    <p>${product.quantity} x ${formatPrice(product.price)} FCFA</p>
                    ${product.weight ? `<p>${product.weight}</p>` : ''}
                </div>
            </div>
        `;
    }

    function createOrderSummary(order) {
        return `
            <p><span>Sous-total:</span> <span>${formatPrice(order.subtotal)} FCFA</span></p>
            <p><span>Livraison:</span> <span>${formatPrice(order.delivery)} FCFA</span></p>
            <p><span>Remise:</span> <span>-${formatPrice(order.discount)} FCFA</span></p>
            <p class="total"><span>Total:</span> <span>${formatPrice(order.total)} FCFA</span></p>
        `;
    }

    function createAddressFormHTML(address) {
        return `
            <div class="modal-content">
                <span class="close-modal">&times;</span>
                <h3>${address ? 'Modifier' : 'Ajouter'} une adresse</h3>
                <form class="address-form">
                    <input type="hidden" name="id" value="${address?.id || ''}">
                    
                    <div class="form-group">
                        <label for="address-name">Nom de l'adresse</label>
                        <input type="text" id="address-name" name="name" value="${address?.name || ''}" required>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="street">Rue et numéro</label>
                            <input type="text" id="street" name="street" value="${address?.street || ''}" required>
                        </div>
                        <div class="form-group">
                            <label for="complement">Complément</label>
                            <input type="text" id="complement" name="complement" value="${address?.complement || ''}">
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-group">
                            <label for="city">Ville</label>
                            <input type="text" id="city" name="city" value="${address?.city || ''}" required>
                        </div>
                        <div class="form-group">
                            <label for="region">Région</label>
                            <input type="text" id="region" name="region" value="${address?.region || ''}" required>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <label for="country">Pays</label>
                        <select id="country" name="country" required>
                            <option value="BF" ${address?.country === 'BF' ? 'selected' : ''}>Burkina Faso</option>
                            <option value="CI" ${address?.country === 'CI' ? 'selected' : ''}>Côte d'Ivoire</option>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Téléphone</label>
                        <div class="phone-input">
                            <span class="prefix">+226</span>
                            <input type="tel" id="phone" name="phone" value="${address?.phone?.replace('+226', '') || ''}" required>
                        </div>
                    </div>
                    
                    <div class="form-group checkbox-group">
                        <input type="checkbox" id="default-address" name="is_default" ${address?.is_default ? 'checked' : ''}>
                        <label for="default-address">Définir comme adresse par défaut</label>
                    </div>
                    
                    <div class="form-actions">
                        <button type="submit" class="btn btn-primary">
                            <span class="btn-text">Enregistrer</span>
                            <div class="loader"></div>
                        </button>
                    </div>
                </form>
            </div>
        `;
    }

    // Fonctions de mock API
    async function mockFetchOrders() {
        await new Promise(resolve => setTimeout(resolve, 800));
        
        return [
            {
                id: 'BSK2023-4587',
                date: new Date().toISOString(),
                status: 'delivered',
                products: [
                    {
                        name: 'Filet de Bœuf',
                        price: 4500,
                        quantity: 2,
                        weight: '500g pièce',
                        image: '../images/boeuf1.jpg'
                    }
                ],
                subtotal: 9000,
                delivery: 2000,
                discount: 1000,
                total: 10000
            }
        ];
    }

    async function mockFetchAddresses() {
        return [
            {
                id: 1,
                street: 'Yagma, à 300m de l\'école At-Taofick',
                city: 'Ouagadougou',
                region: 'Centre',
                country: 'BF',
                is_default: true,
                phone: '+22666123456'
            }
        ];
    }

    async function mockUpdateProfile(data) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        return { success: true };
    }

    async function mockChangePassword(currentPassword, newPassword) {
        await new Promise(resolve => setTimeout(resolve, 1000));
        if (currentPassword !== 'motdepasse123') throw new Error('Mot de passe actuel incorrect');
        return { success: true };
    }

    // Helpers
    function formatPrice(price) {
        return new Intl.NumberFormat('fr-FR').format(price);
    }

    function formatDate(dateString) {
        return new Date(dateString).toLocaleDateString('fr-FR', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    function getStatusText(status) {
        const statusMap = {
            'pending': 'En traitement',
            'shipped': 'Expédiée',
            'delivered': 'Livrée',
            'cancelled': 'Annulée'
        };
        return statusMap[status] || status;
    }
});

// Initialisation du compteur de panier
function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('boucherie_cart')) || [];
    const total = cart.reduce((sum, item) => sum + (item.quantity || 0), 0);
    document.querySelectorAll('#cart-count').forEach(el => el.textContent = total);
}

document.addEventListener('DOMContentLoaded', updateCartCount);
