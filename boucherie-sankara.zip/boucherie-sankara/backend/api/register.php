<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';
require_once __DIR__ . '/../../lib/helpers.php';

// Simuler une base de données (à remplacer par une vraie DB)
$users_db = [];

$data = json_decode(file_get_contents('php://input'), true);

// Validation des données
$required_fields = ['lastname', 'firstname', 'email', 'phone', 'password'];
foreach ($required_fields as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['message' => 'Tous les champs sont obligatoires']);
        exit;
    }
}

// Valider l'email
if (!filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
    http_response_code(400);
    echo json_encode(['message' => 'Email invalide']);
    exit;
}

// Vérifier si l'email existe déjà
if (array_key_exists($data['email'], $users_db)) {
    http_response_code(409);
    echo json_encode(['message' => 'Cet email est déjà utilisé']);
    exit;
}

// Valider le téléphone
if (!preg_match('/^\+226[0-9]{8}$/', $data['phone'])) {
    http_response_code(400);
    echo json_encode(['message' => 'Numéro de téléphone invalide']);
    exit;
}

// Valider le mot de passe
if (strlen($data['password']) < 8) {
    http_response_code(400);
    echo json_encode(['message' => 'Le mot de passe doit contenir au moins 8 caractères']);
    exit;
}

// Hacher le mot de passe
$hashed_password = password_hash($data['password'], PASSWORD_DEFAULT);

// Enregistrer l'utilisateur (simulation)
$user_id = uniqid();
$users_db[$data['email']] = [
    'id' => $user_id,
    'lastname' => sanitize_input($data['lastname']),
    'firstname' => sanitize_input($data['firstname']),
    'email' => $data['email'],
    'phone' => $data['phone'],
    'password' => $hashed_password,
    'created_at' => date('Y-m-d H:i:s')
];

// Enregistrer dans un fichier (simulation)
file_put_contents('users.json', json_encode($users_db));

// Réponse de succès
http_response_code(201);
echo json_encode([
    'message' => 'Inscription réussie',
    'user' => [
        'id' => $user_id,
        'lastname' => $users_db[$data['email']]['lastname'],
        'firstname' => $users_db[$data['email']]['firstname'],
        'email' => $data['email'],
        'phone' => $data['phone']
    ]
]);

function sanitize_input($data) {
    return htmlspecialchars(strip_tags(trim($data)));
}
