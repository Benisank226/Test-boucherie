<?php
header('Content-Type: application/json');
require_once __DIR__ . '/../../config/database.php';

$data = json_decode(file_get_contents('php://input'), true);

// Validation des données
$required = ['method', 'phone', 'amount'];
foreach ($required as $field) {
    if (empty($data[$field])) {
        http_response_code(400);
        echo json_encode(['error' => "Le champ $field est requis"]);
        exit;
    }
}

// Simuler une réponse de l'API de paiement
$transactionId = 'TX' . uniqid();
$response = [
    'success' => true,
    'transactionId' => $transactionId,
    'paymentUrl' => '#',
    'message' => 'Veuillez confirmer le paiement sur votre mobile'
];

// Enregistrer la transaction en base (simulé)
file_put_contents('transactions.log', json_encode([
    'transactionId' => $transactionId,
    'method' => $data['method'],
    'amount' => $data['amount'],
    'status' => 'pending',
    'created_at' => date('Y-m-d H:i:s')
]) . PHP_EOL, FILE_APPEND);

echo json_encode($response);